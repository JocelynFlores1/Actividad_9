package com.example.jocelyn.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText operador1,operador2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        operador1=(EditText)findViewById(R.id.edt_numero1);
        operador2=(EditText)findViewById(R.id.edt_numero2);
    }
    public void Sumar(View view) {
        float n1= Float.parseFloat(operador1.getText().toString());
        float n2= Float.parseFloat(operador2.getText().toString());
        float sum=n1+n2;
        mostrar(sum);
    }

    public void Restar(View view) {
        float n1= Float.parseFloat(operador1.getText().toString());
        float n2= Float.parseFloat(operador2.getText().toString());
        float sum=n1-n2;
        mostrar(sum);

    }

    public void Multiplicar(View view) {
        float n1= Float.parseFloat(operador1.getText().toString());
        float n2= Float.parseFloat(operador2.getText().toString());
        float sum=n1*n2;
        mostrar(sum);
    }

    public void Dividir(View view) {
        float n1= Float.parseFloat(operador1.getText().toString());
        float n2= Float.parseFloat(operador2.getText().toString());
        float sum=n1/n2;
        mostrar(sum);
    }
    public void Modulo(View view) {
        float n1= Float.parseFloat(operador1.getText().toString());
        float n2= Float.parseFloat(operador2.getText().toString());
        float sum=n1%n2;
        mostrar(sum);
    }
    private void mostrar(float sum) {
        Toast.makeText(this, "Resultado operación: "+ sum, Toast.LENGTH_LONG).show();
    }
}
